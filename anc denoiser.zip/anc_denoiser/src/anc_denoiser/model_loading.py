"""Model loading with retry/backoff.

Pretrained weight downloads are the single most common transient failure in
these pipelines (flaky network, registry rate limiting). Retrying a few
times with backoff turns a one-off blip into a non-event instead of failing
an entire batch job.
"""

from __future__ import annotations

import logging
import time
from typing import Callable, TypeVar

import torch

from .exceptions import ModelLoadError

T = TypeVar("T")

_DENOISER_MODEL_MAP = {}


def _denoiser_model_map():
    global _DENOISER_MODEL_MAP
    if not _DENOISER_MODEL_MAP:
        from denoiser.pretrained import dns48, dns64, master64

        _DENOISER_MODEL_MAP = {"dns64": dns64, "dns48": dns48, "master64": master64}
    return _DENOISER_MODEL_MAP


def _with_retry(fn: Callable[[], T], max_retries: int, backoff_sec: float, logger: logging.Logger) -> T:
    last_exc: Exception | None = None
    for attempt in range(1, max_retries + 2):  # first attempt + max_retries retries
        try:
            return fn()
        except Exception as e:  # noqa: BLE001 - intentionally broad; we classify below
            last_exc = e
            if attempt <= max_retries:
                wait = backoff_sec * attempt
                logger.warning(
                    "Model load attempt %d/%d failed (%s); retrying in %.1fs",
                    attempt, max_retries + 1, e, wait,
                )
                time.sleep(wait)
            else:
                logger.error("Model load failed after %d attempts", attempt)
    raise ModelLoadError(f"Failed to load model after retries: {last_exc}") from last_exc


def load_denoiser_model(
    model_name: str,
    device: torch.device,
    max_retries: int = 2,
    retry_backoff_sec: float = 2.0,
    logger: logging.Logger | None = None,
) -> torch.nn.Module:
    """Load a pretrained Demucs-family model (dns64 / dns48 / master64)."""
    log = logger or logging.getLogger("anc_denoiser")
    model_map = _denoiser_model_map()
    if model_name not in model_map:
        raise ModelLoadError(f"Unknown model '{model_name}'. Choose from {list(model_map)}")

    def _load() -> torch.nn.Module:
        log.info("Loading pretrained model: %s ...", model_name)
        try:
            model = model_map[model_name](pretrained=True)
        except AttributeError as e:
            if "set_default_tensor_type" in str(e):
                raise ModelLoadError(
                    "Model loading failed due to a deprecated torch API call "
                    "(torch.set_default_tensor_type) inside the denoiser package. "
                    "Upgrade/downgrade torch or the denoiser package to compatible "
                    "versions rather than silently patching torch's API."
                ) from e
            raise
        return model.to(device).eval()

    return _with_retry(_load, max_retries, retry_backoff_sec, log)


def load_clearvoice_engine(
    model_names: list[str],
    max_retries: int = 2,
    retry_backoff_sec: float = 2.0,
    logger: logging.Logger | None = None,
):
    log = logger or logging.getLogger("anc_denoiser")

    def _load():
        from clearvoice import ClearVoice

        log.info("Loading ClearVoice engine: %s ...", model_names)
        return ClearVoice(task="speech_enhancement", model_names=model_names)

    return _with_retry(_load, max_retries, retry_backoff_sec, log)
