"""Central logging configuration.

Replaces the original scripts' bare print() calls. print() can't be filtered
by severity, can't be redirected to a file/log-aggregator in production, and
gives no timestamps or module context for debugging a failed batch run.
"""

from __future__ import annotations

import logging
import sys


def setup_logging(level: str = "INFO", log_file: str | None = None) -> logging.Logger:
    logger = logging.getLogger("anc_denoiser")
    logger.setLevel(level.upper())
    logger.handlers.clear()  # avoid duplicate handlers if called more than once

    fmt = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    logger.addHandler(stream_handler)

    if log_file:
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setFormatter(fmt)
        logger.addHandler(file_handler)

    return logger


def get_logger() -> logging.Logger:
    return logging.getLogger("anc_denoiser")
