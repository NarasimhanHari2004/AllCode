"""Unified CLI.

Usage (see README.md for the full flag list):

    anc-denoise chunked        -i in.wav -o out.wav
    anc-denoise overlap_add    -i in.wav -o out.wav
    anc-denoise dry_wet_blend  -i in.wav -o out.wav --dry-wet-ratio 0.97
    anc-denoise frcrn          -i in.wav -o out.wav

    anc-denoise chunked -i noisy_dir/ -o out_dir/ --batch

All environment/config-file behavior in config.py applies; CLI flags win
over everything.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from .architectures import base, chunked, dry_wet_blend, frcrn, overlap_add
from .config import DenoiserConfig, load_config
from .device import get_device
from .exceptions import ANCDenoiserError
from .logging_utils import setup_logging
from .model_loading import load_clearvoice_engine, load_denoiser_model

ARCHITECTURE_CHOICES = ["chunked", "overlap_add", "dry_wet_blend", "frcrn"]
_ALIASES = {"1": "chunked", "2": "overlap_add", "3": "dry_wet_blend", "4": "frcrn"}


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="ANC speech denoising pipeline.")
    parser.add_argument("architecture", choices=ARCHITECTURE_CHOICES + list(_ALIASES))
    parser.add_argument("--config", "-c", default=None, help="Path to a YAML config file")
    parser.add_argument("--input", "-i", default=None, help="Input audio file, or folder if --batch")
    parser.add_argument("--output", "-o", default=None, help="Output audio file, or folder if --batch")
    parser.add_argument("--reference", "-r", default=None, help="Genuine clean reference file for PESQ/STOI")
    parser.add_argument("--model", "-m", default=None, choices=["dns64", "dns48", "master64"])
    parser.add_argument("--batch", action="store_true", default=None)
    parser.add_argument("--chunk-len-sec", type=float, default=None)
    parser.add_argument("--overlap-sec", type=float, default=None)
    parser.add_argument("--dry-wet-ratio", type=float, default=None)
    parser.add_argument("--device", default=None, choices=["auto", "cuda", "cpu"])
    parser.add_argument("--no-loudness-match", action="store_true", default=False)
    parser.add_argument("--interactive-plots", action="store_true", default=None)
    parser.add_argument("--log-level", default=None)
    parser.add_argument("--log-file", default=None)
    parser.add_argument("--json-summary", default=None, help="Write a JSON summary of results to this path")
    return parser


def _config_from_args(args: argparse.Namespace) -> DenoiserConfig:
    overrides = {
        "input_path": args.input,
        "output_path": args.output,
        "reference_path": args.reference,
        "model_name": args.model,
        "batch": args.batch,
        "chunk_len_sec": args.chunk_len_sec,
        "overlap_sec": args.overlap_sec,
        "dry_wet_ratio": args.dry_wet_ratio,
        "device": args.device,
        "interactive_plots": args.interactive_plots,
        "log_level": args.log_level,
        "log_file": args.log_file,
    }
    if args.no_loudness_match:
        overrides["match_output_loudness"] = False
    return load_config(yaml_path=args.config, cli_overrides=overrides)


def _run_demucs_family(architecture: str, config: DenoiserConfig, logger) -> list[base.FileResult]:
    device = get_device(config.device, logger=logger)
    model = load_denoiser_model(
        config.model_name, device,
        max_retries=config.max_retries, retry_backoff_sec=config.retry_backoff_sec, logger=logger,
    )
    sr = model.sample_rate

    if architecture == "chunked":
        denoise_fn = chunked.make_denoise_fn(model, device, config.chunk_len_sec)
        label = "Architecture-1 (Chunked)"
    elif architecture == "overlap_add":
        denoise_fn = overlap_add.make_denoise_fn(model, device, config.chunk_len_sec, config.overlap_sec)
        label = "Architecture-2 (Overlap-Add)"
    else:
        denoise_fn = dry_wet_blend.make_denoise_fn(
            model, device, config.chunk_len_sec, config.overlap_sec, config.dry_wet_ratio
        )
        label = "Architecture-3 (Dry/Wet Blend)"

    if config.batch:
        files = base.discover_batch_files(config.input_path, config.audio_extensions)
        os.makedirs(config.output_path, exist_ok=True)
        results = []
        for f in files:
            out_name = os.path.splitext(os.path.basename(f))[0] + "_clean.wav"
            out_path = os.path.join(config.output_path, out_name)
            results.append(process_and_log(f, out_path, sr, denoise_fn, label, config, logger))
        return results

    result = process_and_log(config.input_path, config.output_path, sr, denoise_fn, label, config, logger)
    return [result]


def process_and_log(in_path, out_path, sr, denoise_fn, label, config, logger):
    return base.process_file(in_path, out_path, sr, denoise_fn, label, config, logger=logger)


def _run_frcrn(config: DenoiserConfig, logger) -> list[base.FileResult]:
    engine = load_clearvoice_engine(
        ["FRCRN_SE_16K"],
        max_retries=config.max_retries, retry_backoff_sec=config.retry_backoff_sec, logger=logger,
    )
    sr = 16000
    label = "Architecture-4 (FRCRN)"

    def _process_one(in_path: str, out_path: str) -> base.FileResult:
        # FRCRN reads the file itself via engine(input_path=...), so the
        # denoise_fn closes over in_path rather than using wav_np directly.
        fn = lambda wav_np, sr_: frcrn.denoise_frcrn(engine, in_path)  # noqa: E731
        return base.process_file(in_path, out_path, sr, fn, label, config, logger=logger)

    if config.batch:
        files = base.discover_batch_files(config.input_path, config.audio_extensions)
        os.makedirs(config.output_path, exist_ok=True)
        results = []
        for f in files:
            out_name = os.path.splitext(os.path.basename(f))[0] + "_clean.wav"
            results.append(_process_one(f, os.path.join(config.output_path, out_name)))
        return results

    return [_process_one(config.input_path, config.output_path)]


def _print_summary(results: list[base.FileResult], logger) -> None:
    ok = sum(1 for r in results if r.succeeded)
    logger.info("Done: %d/%d files succeeded", ok, len(results))
    for r in results:
        if r.succeeded:
            logger.info(
                "  OK   %s -> %s (level=%.2fdB snr=%.2fdB)",
                r.input_path, r.output_path, r.metrics["level_change_db"], r.metrics["snr_improvement_db"],
            )
        else:
            logger.error("  FAIL %s: %s", r.input_path, r.error)


def main(argv: list[str] | None = None) -> int:
    parser = _build_arg_parser()
    args = parser.parse_args(argv)
    architecture = _ALIASES.get(args.architecture, args.architecture)

    try:
        config = _config_from_args(args)
    except ANCDenoiserError as e:
        print(f"[CONFIG ERROR] {e}", file=sys.stderr)
        return 2

    logger = setup_logging(config.log_level, config.log_file)

    try:
        if architecture == "frcrn":
            results = _run_frcrn(config, logger)
        else:
            results = _run_demucs_family(architecture, config, logger)
    except ANCDenoiserError as e:
        logger.error("%s", e)
        return 1

    _print_summary(results, logger)

    if args.json_summary:
        with open(args.json_summary, "w", encoding="utf-8") as fh:
            json.dump([r.__dict__ for r in results], fh, indent=2)
        logger.info("Wrote JSON summary to %s", args.json_summary)

    return 0 if all(r.succeeded for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
