"""Custom exception hierarchy.

Keeping these distinct (instead of letting everything fall through as a bare
Exception) lets the CLI decide what's retryable, what's a bad input the user
must fix, and what's a genuine bug worth a full traceback.
"""

from __future__ import annotations


class ANCDenoiserError(Exception):
    """Base class for all errors raised by this package."""


class ConfigError(ANCDenoiserError):
    """Raised for invalid or missing configuration."""


class AudioLoadError(ANCDenoiserError):
    """Raised when an input/reference audio file can't be read or is invalid."""


class ModelLoadError(ANCDenoiserError):
    """Raised when a pretrained model fails to download/initialize.

    Distinguished from other errors because it's often transient (network
    hiccup fetching weights) and worth a retry with backoff.
    """


class InferenceError(ANCDenoiserError):
    """Raised when the forward pass / denoising step fails for a specific file.

    Deliberately NOT fatal at the batch level: process_file() catches this,
    logs it, and continues to the next file rather than aborting a whole run.
    """


class MetricsError(ANCDenoiserError):
    """Raised when metric computation fails (e.g. degenerate/silent audio)."""
