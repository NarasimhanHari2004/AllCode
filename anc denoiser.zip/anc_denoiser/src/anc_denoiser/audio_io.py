"""Audio loading, validation, and the loudness-matching quality fix.

Why loudness matching exists (production-quality fix):
Across all four original architectures, `level_change_db` came out strongly
negative (-6.5 to -7.8 dB) — the denoised output is noticeably quieter than
the input. PESQ and STOI are both sensitive to level mismatches between the
reference and degraded signal (that's a documented property of ITU-T P.862
and the STOI algorithm, not a bug in this code) — a good model can score
worse purely because its output got quieter, independent of how clean it
actually sounds. Matching output RMS back to the input's RMS before saving
removes that confound and should raise PESQ/STOI without touching the
model's actual noise-suppression behavior.
"""

from __future__ import annotations

import os

import numpy as np

from .exceptions import AudioLoadError

_EPS = 1e-10


def validate_input_file(path: str, audio_extensions: tuple[str, ...]) -> None:
    if not os.path.isfile(path):
        raise AudioLoadError(f"Input file not found: {path}")
    if not path.lower().endswith(audio_extensions):
        raise AudioLoadError(
            f"Unsupported extension for {path!r}; expected one of {audio_extensions}"
        )
    if os.path.getsize(path) == 0:
        raise AudioLoadError(f"Input file is empty: {path}")


def load_audio(path: str, target_sr: int) -> "torch.Tensor":  # noqa: F821 - lazy import below
    """Load an audio file as a (1, N) float tensor at target_sr."""
    import librosa
    import torch

    try:
        data, _sr = librosa.load(path, sr=target_sr)
    except Exception as e:  # librosa/soundfile/audioread raise assorted types
        raise AudioLoadError(f"Failed to load audio file {path!r}: {e}") from e

    if data.size == 0:
        raise AudioLoadError(f"Audio file {path!r} decoded to zero samples")
    if not np.isfinite(data).all():
        raise AudioLoadError(f"Audio file {path!r} contains NaN/Inf samples")

    wav = torch.from_numpy(data)
    if wav.dim() == 1:
        wav = wav.unsqueeze(0)
    return wav


def rms(signal: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(signal)) + _EPS))


def match_loudness(
    output_np: np.ndarray,
    reference_level_np: np.ndarray,
    peak_limit: float = 0.98,
) -> np.ndarray:
    """Scale `output_np` so its RMS matches `reference_level_np`'s RMS.

    Gain is capped so the result never exceeds `peak_limit` in absolute
    amplitude, which avoids introducing clipping on transient peaks even
    when a large gain would otherwise be applied to a very quiet output.
    """
    in_rms = rms(reference_level_np)
    out_rms = rms(output_np)
    if out_rms < _EPS:
        return output_np  # silent output; nothing sensible to scale

    gain = in_rms / out_rms
    scaled = output_np * gain

    peak = np.max(np.abs(scaled))
    if peak > peak_limit:
        scaled = scaled * (peak_limit / peak)

    return scaled.astype(output_np.dtype, copy=False)


def save_audio(path: str, data: np.ndarray, sr: int) -> None:
    import soundfile as sf

    out_dir = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(out_dir, exist_ok=True)
    try:
        sf.write(path, data, sr)
    except Exception as e:
        raise AudioLoadError(f"Failed to write output audio to {path!r}: {e}") from e
