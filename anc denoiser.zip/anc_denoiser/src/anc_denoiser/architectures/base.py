"""Shared per-file orchestration: load -> denoise -> post-process -> save -> report.

Each architecture module supplies a `denoise(wav_np, sr) -> np.ndarray`
callable; this module handles everything else identically so the four
scripts can't drift out of sync on I/O, metrics, retries, or logging again.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from typing import Callable

import numpy as np

from .. import audio_io, metrics as metrics_mod, plotting
from ..config import DenoiserConfig
from ..exceptions import AudioLoadError, InferenceError, MetricsError

DenoiseFn = Callable[[np.ndarray, int], np.ndarray]


@dataclass
class FileResult:
    input_path: str
    output_path: str
    plot_path: str | None
    duration_sec: float
    inference_sec: float
    metrics: dict
    perceptual: dict | None
    succeeded: bool
    error: str | None = None


def process_file(
    in_path: str,
    out_path: str,
    sr: int,
    denoise_fn: DenoiseFn,
    architecture_label: str,
    config: DenoiserConfig,
    logger: logging.Logger | None = None,
) -> FileResult:
    """Run one file through the full pipeline. Never raises for per-file
    failures — returns a FileResult with succeeded=False so a batch run can
    continue past a single bad file instead of aborting the whole job.
    """
    log = logger or logging.getLogger("anc_denoiser")
    log.info("Processing: %s", in_path)

    try:
        audio_io.validate_input_file(in_path, config.audio_extensions)
        wav = audio_io.load_audio(in_path, sr)
        noisy_np = wav.squeeze(0).numpy()
        duration_sec = len(noisy_np) / sr
        log.info("Track length: %.1fs", duration_sec)

        t0 = time.time()
        clean_np = denoise_fn(noisy_np, sr)
        inference_sec = time.time() - t0

        if clean_np is None or np.asarray(clean_np).size == 0:
            raise InferenceError(f"Denoise function returned empty output for {in_path}")
        clean_np = np.asarray(clean_np, dtype=np.float32)

        if config.match_output_loudness:
            clean_np = audio_io.match_loudness(clean_np, noisy_np, peak_limit=config.peak_limit)

        audio_io.save_audio(out_path, clean_np, sr)
        log.info("Saved: %s (inference took %.2fs)", out_path, inference_sec)

        m = metrics_mod.calculate_metrics(noisy_np, clean_np, sr)
        log.info(
            "level_change=%.2fdB snr_improvement=%.2fdB spectral_flatness=%.3f",
            m.level_change_db, m.snr_improvement_db, m.spectral_flatness,
        )

        perceptual = None
        if config.reference_path:
            if os.path.isfile(config.reference_path):
                ref_wav = audio_io.load_audio(config.reference_path, sr)
                ref_np = ref_wav.squeeze(0).numpy()
                p = metrics_mod.calculate_perceptual_metrics(ref_np, clean_np, sr)
                perceptual = p.as_dict()
                log.info("PESQ=%s STOI=%s", perceptual["pesq"], perceptual["stoi"])
            else:
                log.warning("--reference file not found: %s; skipping PESQ/STOI", config.reference_path)

        base_name, _ext = os.path.splitext(out_path)
        plot_path = f"{base_name}_metrics.png"
        plotting.save_dashboard(
            noisy_np, clean_np, sr, plot_path, m.as_dict(),
            architecture_label=architecture_label, perceptual=perceptual,
        )
        plotting.open_file_if_interactive(plot_path, interactive=config.interactive_plots, logger=log)

        return FileResult(
            input_path=in_path, output_path=out_path, plot_path=plot_path,
            duration_sec=duration_sec, inference_sec=inference_sec,
            metrics=m.as_dict(), perceptual=perceptual, succeeded=True,
        )

    except (AudioLoadError, InferenceError, MetricsError) as e:
        log.error("Failed to process %s: %s", in_path, e)
        return FileResult(
            input_path=in_path, output_path=out_path, plot_path=None,
            duration_sec=0.0, inference_sec=0.0, metrics={}, perceptual=None,
            succeeded=False, error=str(e),
        )
    except Exception as e:  # unexpected bug — log with traceback, still don't crash the batch
        log.exception("Unexpected error processing %s", in_path)
        return FileResult(
            input_path=in_path, output_path=out_path, plot_path=None,
            duration_sec=0.0, inference_sec=0.0, metrics={}, perceptual=None,
            succeeded=False, error=f"{type(e).__name__}: {e}",
        )


def discover_batch_files(input_dir: str, audio_extensions: tuple[str, ...]) -> list[str]:
    if not os.path.isdir(input_dir):
        raise AudioLoadError(f"Batch input folder not found: {input_dir}")
    files = sorted(
        os.path.join(input_dir, f)
        for f in os.listdir(input_dir)
        if f.lower().endswith(audio_extensions)
    )
    if not files:
        raise AudioLoadError(f"No compatible audio files found in {input_dir}")
    return files
