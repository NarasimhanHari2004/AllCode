"""Architecture 3: Overlap-Add + Dry/Wet blend.

Quality fix vs. the original: the original hardcoded a 90% wet / 10% dry
blend intended to soften robotic denoising artifacts. Measured against a
real reference, that blend cost noticeably more than it gave back — SNR
improvement dropped to ~12 dB (vs. ~28-35 dB for the other architectures)
and PESQ/STOI both came out lowest of the four, because the 10% noisy
bleed-back reintroduces real noise energy, not just "warmth". The default
here is now configurable (`dry_wet_ratio` in config, default 0.97 wet) so
you can dial in the tradeoff, rather than a fixed value baked into the code.
Set it to 1.0 to disable blending entirely and match Architecture 2.
"""

from __future__ import annotations

import numpy as np

from .overlap_add import denoise_overlap_add


def denoise_dry_wet_blend(
    model,
    wav,
    device,
    chunk_len_sec: float = 8.0,
    overlap_sec: float = 3.0,
    dry_wet_ratio: float = 0.97,
) -> np.ndarray:
    clean_np = denoise_overlap_add(
        model, wav, device, chunk_len_sec=chunk_len_sec, overlap_sec=overlap_sec
    )
    noisy_np = wav.squeeze(0).numpy()

    min_len = min(len(clean_np), len(noisy_np))
    clean_np = clean_np[:min_len]
    noisy_np = noisy_np[:min_len]

    blend = (clean_np * dry_wet_ratio) + (noisy_np * (1.0 - dry_wet_ratio))

    peak = np.max(np.abs(blend))
    if peak > 1.0:
        blend = blend / peak

    return blend.astype(np.float32)


def make_denoise_fn(
    model,
    device,
    chunk_len_sec: float,
    overlap_sec: float,
    dry_wet_ratio: float,
):
    def _fn(wav_np: np.ndarray, sr: int) -> np.ndarray:
        import torch

        wav = torch.from_numpy(wav_np).unsqueeze(0)
        return denoise_dry_wet_blend(
            model, wav, device,
            chunk_len_sec=chunk_len_sec, overlap_sec=overlap_sec, dry_wet_ratio=dry_wet_ratio,
        )

    return _fn
