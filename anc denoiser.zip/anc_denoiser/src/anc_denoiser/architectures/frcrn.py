"""Architecture 4: ClearVoice FRCRN (time-frequency domain).

Best measured PESQ/STOI of the four architectures. Does not support batch
mode upstream in ClearVoice's API the way the Demucs-family models do here,
so the CLI loops per-file itself for --batch instead.
"""

from __future__ import annotations

import numpy as np


def denoise_frcrn(engine, in_path: str) -> np.ndarray:
    """Run the ClearVoice engine and normalize its return type.

    Quality/robustness fix vs. the original: ClearVoice's __call__ can
    return a dict (keyed by model name) when built with multiple
    model_names, or in principle a list/tuple, not only a bare ndarray.
    Calling .ndim directly on whatever came back raised AttributeError on
    anything but a plain ndarray. This normalizes first.
    """
    output = engine(input_path=in_path, online_write=False)

    if isinstance(output, dict):
        output = next(iter(output.values()))
    output = np.asarray(output)

    if output.ndim > 1:
        return output[0, :]
    return output


def make_denoise_fn(engine):
    def _fn(wav_np: np.ndarray, sr: int, in_path: str) -> np.ndarray:
        return denoise_frcrn(engine, in_path)

    return _fn
