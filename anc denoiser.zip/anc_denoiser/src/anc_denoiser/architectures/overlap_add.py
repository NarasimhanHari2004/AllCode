"""Architecture 2: Overlap-Add (OLA) with equal-power crossfade.

Two quality fixes vs. the original:

1. The original used a *linear* amplitude crossfade (np.linspace ramps).
   Linear amplitude crossfades between two uncorrelated signal segments
   cause a small perceived loudness dip in the middle of the transition,
   because amplitude (not power) sums linearly while loudness tracks
   power/energy. This version uses an equal-power (raised cosine) crossfade
   instead, which keeps summed energy ~constant across the transition.

2. EDGE FADE BUG (present in the original for both architectures 2 and 3,
   confirmed here with a numeric identity-reconstruction test): the window
   was applied unconditionally to every chunk, including the first and
   last. That fades the very first `overlap_sec` and last `overlap_sec` of
   *every output file* down toward silence, because there's no neighboring
   chunk on that side to blend with — the weighted-average normalization
   divides by a weight that itself trails to ~0 at the true start/end, so
   the edges of the file get quietly attenuated rather than reconstructed
   at full level. Fixed by only applying the fade-in on non-first chunks
   and the fade-out on non-last chunks.
"""

from __future__ import annotations

import numpy as np

from ..exceptions import InferenceError


def _equal_power_window(
    chunk_samples: int, overlap_samples: int, is_first: bool, is_last: bool
) -> np.ndarray:
    """Per-chunk crossfade window.

    Fade-in is omitted for the first chunk (nothing precedes it to blend
    with) and fade-out is omitted for the last chunk (nothing follows it) —
    see the edge-fade bug note in the module docstring.
    """
    window = np.ones(chunk_samples, dtype=np.float32)
    if overlap_samples > 0:
        theta = np.linspace(0, np.pi / 2, overlap_samples, dtype=np.float32)
        if not is_first:
            window[:overlap_samples] = np.sin(theta)
        if not is_last:
            window[-overlap_samples:] = np.cos(theta)
    return window


def denoise_overlap_add(
    model,
    wav,
    device,
    chunk_len_sec: float = 8.0,
    overlap_sec: float = 3.0,
) -> np.ndarray:
    import torch  # lazy: keeps _equal_power_window unit-testable without torch installed

    sr = model.sample_rate
    chunk_samples = max(1, int(chunk_len_sec * sr))
    overlap_samples = max(0, int(overlap_sec * sr))
    step_samples = chunk_samples - overlap_samples

    if step_samples <= 0:
        raise InferenceError(
            f"overlap_sec ({overlap_sec}s) must be smaller than "
            f"chunk_len_sec ({chunk_len_sec}s) so that step_samples stays positive."
        )

    total_samples = wav.shape[-1]
    output_audio = np.zeros(total_samples, dtype=np.float32)
    weight_mask = np.zeros(total_samples, dtype=np.float32)

    starts = [s for s in range(0, total_samples, step_samples) if s < total_samples]

    for idx, start in enumerate(starts):
        end = start + chunk_samples
        is_first = idx == 0
        is_last = idx == len(starts) - 1
        window = _equal_power_window(chunk_samples, overlap_samples, is_first, is_last)

        pad_len = 0
        if end > total_samples:
            pad_len = end - total_samples
            chunk = wav[:, start:total_samples]
            chunk = torch.nn.functional.pad(chunk, (0, pad_len))
        else:
            chunk = wav[:, start:end]

        chunk = chunk.to(device)

        with torch.no_grad():
            if device.type == "cuda":
                with torch.autocast(device_type="cuda", dtype=torch.float16):
                    out_chunk = model(chunk.unsqueeze(0))
            else:
                out_chunk = model(chunk.unsqueeze(0))

        out_chunk_np = out_chunk.squeeze(0).squeeze(0).detach().cpu().numpy()

        if pad_len > 0:
            out_chunk_np = out_chunk_np[:-pad_len]
            current_chunk_len = total_samples - start
        else:
            current_chunk_len = chunk_samples

        active_window = window[:current_chunk_len]
        output_audio[start : start + current_chunk_len] += out_chunk_np * active_window
        weight_mask[start : start + current_chunk_len] += active_window

        if device.type == "cuda":
            torch.cuda.empty_cache()

    weight_mask[weight_mask == 0] = 1.0
    return (output_audio / weight_mask).astype(np.float32)


def make_denoise_fn(model, device, chunk_len_sec: float, overlap_sec: float):
    def _fn(wav_np: np.ndarray, sr: int) -> np.ndarray:
        import torch

        wav = torch.from_numpy(wav_np).unsqueeze(0)
        return denoise_overlap_add(
            model, wav, device, chunk_len_sec=chunk_len_sec, overlap_sec=overlap_sec
        )

    return _fn
