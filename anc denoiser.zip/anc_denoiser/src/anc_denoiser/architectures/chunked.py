"""Architecture 1: fixed-size chunk inference (no crossfade).

Simplest and fastest architecture. Chunk boundaries can produce audible
discontinuities on some material; Architecture 2 (overlap_add) trades some
speed for a smoother result. Use this when throughput matters more than the
last bit of transition smoothness, or for files short enough that boundary
artifacts don't arise.
"""

from __future__ import annotations

import numpy as np


def denoise_chunked(
    model,
    wav,
    device,
    chunk_len_sec: float = 10.0,
) -> np.ndarray:
    import torch

    sr = model.sample_rate
    chunk_samples = max(1, int(chunk_len_sec * sr))
    total_samples = wav.shape[-1]
    enhanced_chunks: list[torch.Tensor] = []

    for start in range(0, total_samples, chunk_samples):
        end = min(start + chunk_samples, total_samples)
        chunk = wav[:, start:end]

        pad_len = 0
        if chunk.shape[-1] < sr:
            pad_len = sr - chunk.shape[-1]
            chunk = torch.nn.functional.pad(chunk, (0, pad_len))

        chunk = chunk.to(device)

        with torch.no_grad():
            if device.type == "cuda":
                with torch.autocast(device_type="cuda", dtype=torch.float16):
                    out_chunk = model(chunk.unsqueeze(0))
            else:
                out_chunk = model(chunk.unsqueeze(0))

        out_chunk = out_chunk.squeeze(0).detach().cpu()
        if pad_len > 0:
            out_chunk = out_chunk[:, :-pad_len]
        enhanced_chunks.append(out_chunk)

        if device.type == "cuda":
            torch.cuda.empty_cache()

    result = torch.cat(enhanced_chunks, dim=-1)
    return result.squeeze(0).numpy()


def make_denoise_fn(model, device, chunk_len_sec: float):
    def _fn(wav_np: np.ndarray, sr: int) -> np.ndarray:
        import torch

        wav = torch.from_numpy(wav_np).unsqueeze(0)
        return denoise_chunked(model, wav, device, chunk_len_sec=chunk_len_sec)

    return _fn
