"""Configuration loading.

Precedence (highest wins): CLI flags > environment variables > YAML config
file > dataclass defaults. This is the standard 12-factor precedence order,
so ops can override a shipped config.yaml with env vars in a container
without editing files, while developers can still just edit YAML locally.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, fields, replace
from pathlib import Path
from typing import Any

import yaml

from .exceptions import ConfigError

_ENV_PREFIX = "ANC_"


@dataclass(frozen=True)
class DenoiserConfig:
    # --- I/O ---
    input_path: str = "test_input.wav"
    output_path: str = "cleaned_output.wav"
    reference_path: str | None = None
    batch: bool = False

    # --- Model ---
    model_name: str = "dns64"  # dns64 > dns48 in quality; see README quality notes
    chunk_len_sec: float = 10.0
    overlap_sec: float = 3.0  # only used by overlap_add / dry_wet_blend

    # --- Architecture-3 specific ---
    dry_wet_ratio: float = 0.97  # fraction WET (denoised). 0.90 measured worse
    # PESQ/STOI in practice; see README "Output quality" notes.

    # --- Post-processing (quality) ---
    match_output_loudness: bool = True  # RMS-match output to input pre-save
    peak_limit: float = 0.98  # safety ceiling to avoid clipping after any gain

    # --- Runtime ---
    device: str = "auto"  # "auto" | "cuda" | "cpu"
    interactive_plots: bool = False  # only meaningful for chunked architecture
    log_level: str = "INFO"
    log_file: str | None = None
    max_retries: int = 2  # model load / transient failure retry count
    retry_backoff_sec: float = 2.0

    audio_extensions: tuple[str, ...] = (".wav", ".flac", ".mp3", ".ogg", ".m4a")

    def validate(self) -> None:
        errors: list[str] = []

        if self.model_name not in {"dns64", "dns48", "master64"}:
            errors.append(f"model_name must be one of dns64/dns48/master64, got {self.model_name!r}")
        if self.chunk_len_sec <= 0:
            errors.append("chunk_len_sec must be > 0")
        if self.overlap_sec < 0:
            errors.append("overlap_sec must be >= 0")
        if self.overlap_sec >= self.chunk_len_sec:
            errors.append(
                f"overlap_sec ({self.overlap_sec}) must be strictly less than "
                f"chunk_len_sec ({self.chunk_len_sec})"
            )
        if not (0.0 <= self.dry_wet_ratio <= 1.0):
            errors.append("dry_wet_ratio must be between 0 and 1")
        if not (0.0 < self.peak_limit <= 1.0):
            errors.append("peak_limit must be in (0, 1]")
        if self.device not in {"auto", "cuda", "cpu"}:
            errors.append(f"device must be auto/cuda/cpu, got {self.device!r}")
        if self.max_retries < 0:
            errors.append("max_retries must be >= 0")
        if self.log_level.upper() not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
            errors.append(f"log_level {self.log_level!r} is not a valid logging level")

        if errors:
            raise ConfigError("Invalid configuration:\n  - " + "\n  - ".join(errors))


def _load_yaml(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.is_file():
        raise ConfigError(f"Config file not found: {p}")
    try:
        with p.open("r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
    except yaml.YAMLError as e:
        raise ConfigError(f"Could not parse YAML config {p}: {e}") from e
    if not isinstance(data, dict):
        raise ConfigError(f"Config file {p} must contain a top-level mapping")
    return data


def _coerce(field_type: type, raw: str) -> Any:
    if field_type is bool:
        return raw.strip().lower() in {"1", "true", "yes", "on"}
    if field_type is float:
        return float(raw)
    if field_type is int:
        return int(raw)
    if field_type is tuple:
        return tuple(x.strip() for x in raw.split(",") if x.strip())
    return raw


def _from_env(cfg: DenoiserConfig) -> DenoiserConfig:
    updates: dict[str, Any] = {}
    for f in fields(cfg):
        env_key = _ENV_PREFIX + f.name.upper()
        if env_key in os.environ:
            try:
                updates[f.name] = _coerce(type(getattr(cfg, f.name)), os.environ[env_key])
            except (TypeError, ValueError) as e:
                raise ConfigError(f"Invalid value for {env_key}: {e}") from e
    return replace(cfg, **updates) if updates else cfg


def load_config(
    yaml_path: str | Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
) -> DenoiserConfig:
    """Build a validated config from defaults -> YAML -> env vars -> CLI overrides."""
    cfg = DenoiserConfig()

    if yaml_path is not None:
        yaml_data = _load_yaml(yaml_path)
        known = {f.name for f in fields(cfg)}
        unknown = set(yaml_data) - known
        if unknown:
            raise ConfigError(f"Unknown config keys in {yaml_path}: {sorted(unknown)}")
        cfg = replace(cfg, **yaml_data)

    cfg = _from_env(cfg)

    if cli_overrides:
        cli_overrides = {k: v for k, v in cli_overrides.items() if v is not None}
        cfg = replace(cfg, **cli_overrides)

    cfg.validate()
    return cfg
