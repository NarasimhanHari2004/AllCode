"""Shared metrics-dashboard plot generation.

Uses the non-interactive Agg backend unconditionally. The original scripts
mixed TkAgg-with-plt.show(), Agg-with-os.startfile(), and inconsistent
--batch handling for whether a window blocks execution; in a production/
headless/CI/server context there is no display to show a window on at all,
so this always renders to a file and lets the caller decide whether to open
it (see `open_file_if_interactive`).
"""

from __future__ import annotations

import logging
import os
import platform
import subprocess

import librosa
import librosa.display
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402


def _format_metrics_text(architecture_label: str, metrics: dict, perceptual: dict | None) -> str:
    lines = [
        f"PERFORMANCE SUMMARY METRICS ({architecture_label}):",
        "-" * 72,
        f"\u2022 Overall Level Change: {metrics['level_change_db']:.2f} dB",
        f"\u2022 Estimated SNR Improvement: {metrics['snr_improvement_db']:.2f} dB",
        f"\u2022 Spectral Flatness (denoised): {metrics['spectral_flatness']:.3f}",
    ]
    if perceptual is not None:
        pesq_str = f"{perceptual['pesq']:.3f}" if perceptual.get("pesq") is not None else "N/A"
        stoi_str = f"{perceptual['stoi']:.3f}" if perceptual.get("stoi") is not None else "N/A"
        lines.append(f"\u2022 PESQ (vs. reference): {pesq_str}")
        lines.append(f"\u2022 STOI (vs. reference): {stoi_str}")
    else:
        lines.append("\u2022 PESQ/STOI: skipped (no --reference clean file supplied)")
    return "\n".join(lines)


def save_dashboard(
    noisy_np: np.ndarray,
    clean_np: np.ndarray,
    sr: int,
    plot_path: str,
    metrics: dict,
    architecture_label: str,
    perceptual: dict | None = None,
) -> str:
    plt.close("all")

    min_len = min(len(noisy_np), len(clean_np))
    noisy_np = noisy_np[:min_len]
    clean_np = clean_np[:min_len]
    time_axis = np.linspace(0, min_len / sr, num=min_len)

    fig = plt.figure(figsize=(14, 9))
    fig.suptitle(f"{architecture_label}: Speech Denoising Pipeline for ANC", fontsize=16, fontweight="bold")

    plt.subplot(3, 2, 1)
    plt.plot(time_axis, noisy_np, color="crimson", alpha=0.7)
    plt.title("Noisy Signal Waveform")
    plt.ylabel("Amplitude")
    plt.grid(True, linestyle="--", alpha=0.5)

    plt.subplot(3, 2, 2)
    plt.plot(time_axis, clean_np, color="dodgerblue", alpha=0.7)
    plt.title("Enhanced (Cleaned) Waveform")
    plt.ylabel("Amplitude")
    plt.grid(True, linestyle="--", alpha=0.5)

    plt.subplot(3, 2, 3)
    d_noisy = librosa.amplitude_to_db(np.abs(librosa.stft(noisy_np)), ref=np.max)
    librosa.display.specshow(d_noisy, sr=sr, x_axis="time", y_axis="linear", cmap="magma")
    plt.colorbar(format="%+2.0f dB")
    plt.title("Noisy Spectrogram")

    plt.subplot(3, 2, 4)
    d_clean = librosa.amplitude_to_db(np.abs(librosa.stft(clean_np)), ref=np.max)
    librosa.display.specshow(d_clean, sr=sr, x_axis="time", y_axis="linear", cmap="magma")
    plt.colorbar(format="%+2.0f dB")
    plt.title("Clean Spectrogram")

    plt.subplot(3, 1, 3)
    plt.axis("off")
    text_str = _format_metrics_text(architecture_label, metrics, perceptual)
    plt.text(
        0.05, 0.3, text_str, fontsize=13, family="monospace",
        bbox=dict(facecolor="lightgray", alpha=0.5, boxstyle="round,pad=1"),
    )

    plt.tight_layout(rect=[0, 0, 1, 0.95])

    out_dir = os.path.dirname(os.path.abspath(plot_path)) or "."
    os.makedirs(out_dir, exist_ok=True)
    plt.savefig(plot_path, dpi=150)
    plt.close(fig)
    return plot_path


def open_file_if_interactive(path: str, interactive: bool, logger: logging.Logger | None = None) -> None:
    """Best-effort open of a generated file in the OS image viewer.

    Cross-platform (the original scripts used Windows-only os.startfile,
    which raises AttributeError on macOS/Linux). Silently degrades to a
    log message if no viewer / no display is available (e.g. CI, servers,
    --batch runs), which is the expected case in production.
    """
    log = logger or logging.getLogger("anc_denoiser")
    if not interactive:
        return
    try:
        system = platform.system()
        if system == "Windows":
            os.startfile(path)  # type: ignore[attr-defined]
        elif system == "Darwin":
            subprocess.run(["open", path], check=False)
        else:
            subprocess.run(["xdg-open", path], check=False)
        log.info("Opened dashboard image: %s", path)
    except Exception as e:
        log.debug("Could not auto-open dashboard image (%s); it was still saved to %s", e, path)
