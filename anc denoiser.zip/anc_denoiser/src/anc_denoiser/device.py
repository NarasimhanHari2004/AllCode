"""Hardware device selection."""

from __future__ import annotations

import logging

import torch


def get_device(preference: str = "auto", logger: logging.Logger | None = None) -> torch.device:
    """Resolve the torch device to use.

    preference: "auto" picks CUDA if available else CPU; "cuda"/"cpu" force
    that backend (raising if "cuda" was forced but unavailable, since a
    silent CPU fallback in that case would just hide a real deployment bug).
    """
    log = logger or logging.getLogger("anc_denoiser")

    if preference == "cpu":
        log.info("Device forced to CPU by config.")
        return torch.device("cpu")

    cuda_available = torch.cuda.is_available()

    if preference == "cuda" and not cuda_available:
        raise RuntimeError(
            "device='cuda' was requested but no CUDA GPU is available. "
            "Use device='auto' to allow CPU fallback, or fix the CUDA install."
        )

    if cuda_available:
        device = torch.device("cuda")
        log.info("CUDA GPU detected: %s", torch.cuda.get_device_name(0))
        torch.backends.cudnn.benchmark = True
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
    else:
        device = torch.device("cpu")
        log.warning("No GPU detected — falling back to CPU. This will be slower.")

    return device
