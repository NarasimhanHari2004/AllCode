"""anc_denoiser: production speech-denoising pipeline for ANC evaluation.

Four interchangeable architectures share one metrics/audio-IO/config core:

  1. chunked        - simple fixed-size chunk inference (Demucs family)
  2. overlap_add     - Hann-windowed overlap-add crossfade (Demucs family)
  3. dry_wet_blend    - overlap-add + configurable dry/wet blend (Demucs family)
  4. frcrn           - ClearVoice FRCRN time-frequency domain model

See README.md for CLI usage and configs/default.yaml for tunables.
"""

__version__ = "1.0.0"
