"""Reference-free and reference-based audio quality metrics.

This is the single shared implementation. In the original four scripts this
exact ~40-line function was copy-pasted four times, which meant a fix (the
level_change_db sign inversion) had to be applied identically in four
places by hand — exactly the kind of drift that causes production bugs.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .exceptions import MetricsError

_EPS = 1e-10


@dataclass(frozen=True)
class ReferenceFreeMetrics:
    level_change_db: float
    snr_improvement_db: float
    spectral_flatness: float

    def as_dict(self) -> dict[str, float]:
        return {
            "level_change_db": self.level_change_db,
            "snr_improvement_db": self.snr_improvement_db,
            "spectral_flatness": self.spectral_flatness,
        }


@dataclass(frozen=True)
class PerceptualMetrics:
    pesq: float | None
    stoi: float | None

    def as_dict(self) -> dict[str, float | None]:
        return {"pesq": self.pesq, "stoi": self.stoi}


def _estimate_snr(signal: np.ndarray, sr: int, frame_ms: int) -> float:
    frame_len = max(1, int(sr * frame_ms / 1000))
    n_frames = len(signal) // frame_len
    if n_frames == 0:
        return 0.0
    frames = signal[: n_frames * frame_len].reshape(n_frames, frame_len)
    frame_power = np.mean(frames**2, axis=1)
    noise_floor = np.percentile(frame_power, 10) + _EPS
    active_power = np.mean(frame_power) + _EPS
    return 10 * np.log10(active_power / noise_floor)


def calculate_metrics(
    noisy_np: np.ndarray, clean_np: np.ndarray, sr: int, frame_ms: int = 20
) -> ReferenceFreeMetrics:
    """Reference-free metrics (no paired clean ground-truth needed).

    - level_change_db: overall RMS power change, output-relative-to-input
      (positive = output louder, negative = output quieter). This is a
      strength-of-effect indicator, NOT "amount of noise removed" — some of
      the power change is speech energy the model altered too.
    - snr_improvement_db: estimates a noise floor independently in the noisy
      and denoised signals from each one's own quietest short-time frames,
      converts each to an SNR estimate, and reports the difference. This is
      an estimate, not a true paired SNR delta (no ground truth exists).
    - spectral_flatness: 0 (tonal) to 1 (noise-like), computed on the
      denoised signal. An honest broadband stand-in for THD, which requires
      a periodic tone to be meaningful and therefore doesn't apply to speech.
    """
    if noisy_np.size == 0 or clean_np.size == 0:
        raise MetricsError("Cannot compute metrics on empty audio arrays")

    min_len = min(len(noisy_np), len(clean_np))
    noisy_np = noisy_np[:min_len]
    clean_np = clean_np[:min_len]

    power_noisy = np.mean(noisy_np**2)
    power_clean = np.mean(clean_np**2)
    level_change_db = 10 * np.log10((power_clean + _EPS) / (power_noisy + _EPS))

    snr_improvement_db = _estimate_snr(clean_np, sr, frame_ms) - _estimate_snr(
        noisy_np, sr, frame_ms
    )

    fft_clean = np.abs(np.fft.rfft(clean_np)) + _EPS
    geo_mean = np.exp(np.mean(np.log(fft_clean)))
    arith_mean = np.mean(fft_clean)
    spectral_flatness = float(geo_mean / arith_mean)

    return ReferenceFreeMetrics(
        level_change_db=float(level_change_db),
        snr_improvement_db=float(snr_improvement_db),
        spectral_flatness=spectral_flatness,
    )


def calculate_perceptual_metrics(
    reference_np: np.ndarray, degraded_np: np.ndarray, sr: int
) -> PerceptualMetrics:
    """PESQ (ITU-T P.862) and STOI — require a genuine clean reference signal.

    Only call this with a real clean recording via --reference; comparing
    against the noisy input instead is not a valid use of either metric.
    """
    import librosa
    from pesq import pesq
    from pystoi import stoi

    min_len = min(len(reference_np), len(degraded_np))
    reference_np = reference_np[:min_len].astype(np.float32)
    degraded_np = degraded_np[:min_len].astype(np.float32)

    if sr not in (8000, 16000):
        eval_sr = 16000
        reference_eval = librosa.resample(reference_np, orig_sr=sr, target_sr=eval_sr)
        degraded_eval = librosa.resample(degraded_np, orig_sr=sr, target_sr=eval_sr)
    else:
        eval_sr = sr
        reference_eval = reference_np
        degraded_eval = degraded_np

    pesq_mode = "wb" if eval_sr == 16000 else "nb"

    pesq_score: float | None
    try:
        pesq_score = float(pesq(eval_sr, reference_eval, degraded_eval, pesq_mode))
    except Exception:
        pesq_score = None

    stoi_score: float | None
    try:
        stoi_score = float(stoi(reference_np, degraded_np, sr, extended=False))
    except Exception:
        stoi_score = None

    return PerceptualMetrics(pesq=pesq_score, stoi=stoi_score)
