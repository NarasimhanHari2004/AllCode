"""Regression test for the edge-fade bug fix in overlap_add.py.

This does NOT import the torch-dependent denoise_overlap_add function
directly (torch may not be installed in every test environment); instead
it re-implements the identical window/accumulation math in pure numpy and
checks it against `_equal_power_window`, which IS pure numpy and imported
for real. This locks in the fix: an identity "model" run through the
overlap-add reconstruction must reproduce the input exactly, including at
the very first and last `overlap_sec` of the file.
"""

import unittest

import numpy as np

from anc_denoiser.architectures.overlap_add import _equal_power_window


def _ola_reconstruct_with_real_window(signal: np.ndarray, chunk_samples: int, overlap_samples: int) -> np.ndarray:
    step = chunk_samples - overlap_samples
    total = len(signal)
    out = np.zeros(total, dtype=np.float32)
    weight = np.zeros(total, dtype=np.float32)
    starts = [s for s in range(0, total, step) if s < total]

    for idx, start in enumerate(starts):
        end = start + chunk_samples
        is_first = idx == 0
        is_last = idx == len(starts) - 1
        window = _equal_power_window(chunk_samples, overlap_samples, is_first, is_last)

        pad = 0
        if end > total:
            pad = end - total
            chunk = np.pad(signal[start:total], (0, pad))
        else:
            chunk = signal[start:end]

        out_chunk = chunk  # identity "model"
        if pad > 0:
            out_chunk = out_chunk[:-pad]
            cur_len = total - start
        else:
            cur_len = chunk_samples

        w = window[:cur_len]
        out[start : start + cur_len] += out_chunk * w
        weight[start : start + cur_len] += w

    weight[weight == 0] = 1.0
    return out / weight


class TestOverlapAddEdgeFade(unittest.TestCase):
    def test_first_chunk_has_no_fade_in(self):
        window = _equal_power_window(chunk_samples=8000, overlap_samples=3000, is_first=True, is_last=False)
        self.assertEqual(window[0], 1.0, "first sample of the first chunk must not be faded")
        np.testing.assert_allclose(window[:3000], 1.0)

    def test_last_chunk_has_no_fade_out(self):
        window = _equal_power_window(chunk_samples=8000, overlap_samples=3000, is_first=False, is_last=True)
        np.testing.assert_allclose(window[-3000:], 1.0)

    def test_middle_chunk_fades_both_sides(self):
        window = _equal_power_window(chunk_samples=8000, overlap_samples=3000, is_first=False, is_last=False)
        self.assertLess(window[0], 0.1)
        self.assertLess(window[-1], 0.1)

    def test_identity_reconstruction_exact_at_signal_boundaries(self):
        rng = np.random.default_rng(0)
        for total_len in [10007, 16000, 40001, 12345]:
            signal = rng.normal(0, 1, total_len).astype(np.float32)
            recon = _ola_reconstruct_with_real_window(signal, chunk_samples=8000, overlap_samples=3000)
            max_err = np.max(np.abs(recon - signal))
            self.assertLess(
                max_err, 1e-4,
                f"OLA identity reconstruction should be exact (len={total_len}, max_err={max_err})",
            )
            # Specifically check the very first and last samples, which is
            # exactly where the original edge-fade bug attenuated toward 0.
            self.assertAlmostEqual(recon[0], signal[0], places=3)
            self.assertAlmostEqual(recon[-1], signal[-1], places=3)


if __name__ == "__main__":
    unittest.main()
