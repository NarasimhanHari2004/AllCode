import unittest

import numpy as np

from anc_denoiser.audio_io import match_loudness, rms


class TestMatchLoudness(unittest.TestCase):
    def test_matches_target_rms(self):
        # Low amplitude so the corrective gain doesn't hit peak_limit — this
        # test is specifically about the RMS-matching math, not the safety
        # clamp (that's covered separately in test_never_exceeds_peak_limit).
        rng = np.random.default_rng(0)
        reference = rng.normal(0, 0.1, 16000).astype(np.float32)
        quiet_output = reference * 0.2  # simulate a quieter denoised output

        matched = match_loudness(quiet_output, reference, peak_limit=0.98)
        self.assertAlmostEqual(rms(matched), rms(reference), delta=1e-3)

    def test_never_exceeds_peak_limit(self):
        rng = np.random.default_rng(1)
        reference = rng.normal(0, 0.9, 16000).astype(np.float32)  # loud reference
        quiet_output = reference * 0.05  # very quiet output -> large gain needed

        matched = match_loudness(quiet_output, reference, peak_limit=0.98)
        self.assertLessEqual(np.max(np.abs(matched)), 0.98 + 1e-6)

    def test_silent_output_is_left_unchanged(self):
        reference = np.ones(1000, dtype=np.float32) * 0.5
        silent_output = np.zeros(1000, dtype=np.float32)

        matched = match_loudness(silent_output, reference)
        np.testing.assert_array_equal(matched, silent_output)

    def test_identity_when_already_matched(self):
        # Low amplitude, same reasoning as test_matches_target_rms above.
        rng = np.random.default_rng(2)
        signal = rng.normal(0, 0.1, 8000).astype(np.float32)

        matched = match_loudness(signal.copy(), signal, peak_limit=0.98)
        np.testing.assert_allclose(matched, signal, atol=1e-4)


if __name__ == "__main__":
    unittest.main()
