import unittest

import numpy as np

from anc_denoiser.exceptions import MetricsError
from anc_denoiser.metrics import calculate_metrics


class TestCalculateMetrics(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(42)
        self.sr = 16000
        self.noisy = rng.normal(0, 0.5, self.sr * 2).astype(np.float32)

    def test_level_change_sign_louder(self):
        clean = self.noisy * 2.0  # doubled amplitude -> ~+6 dB
        m = calculate_metrics(self.noisy, clean, self.sr)
        self.assertGreater(m.level_change_db, 0, "louder output must report positive dB")
        self.assertAlmostEqual(m.level_change_db, 20 * np.log10(2.0), delta=0.05)

    def test_level_change_sign_quieter(self):
        clean = self.noisy * 0.5  # halved amplitude -> ~-6 dB
        m = calculate_metrics(self.noisy, clean, self.sr)
        self.assertLess(m.level_change_db, 0, "quieter output must report negative dB")
        self.assertAlmostEqual(m.level_change_db, 20 * np.log10(0.5), delta=0.05)

    def test_level_change_identity_is_zero(self):
        m = calculate_metrics(self.noisy, self.noisy.copy(), self.sr)
        self.assertAlmostEqual(m.level_change_db, 0.0, delta=1e-6)

    def test_spectral_flatness_bounds(self):
        m = calculate_metrics(self.noisy, self.noisy.copy(), self.sr)
        self.assertGreaterEqual(m.spectral_flatness, 0.0)
        self.assertLessEqual(m.spectral_flatness, 1.0 + 1e-6)

    def test_pure_tone_has_low_spectral_flatness(self):
        t = np.linspace(0, 1, self.sr, endpoint=False)
        tone = np.sin(2 * np.pi * 440 * t).astype(np.float32)
        m = calculate_metrics(tone, tone, self.sr)
        self.assertLess(m.spectral_flatness, 0.05)

    def test_white_noise_has_high_spectral_flatness(self):
        rng = np.random.default_rng(1)
        noise = rng.normal(0, 1, self.sr).astype(np.float32)
        m = calculate_metrics(noise, noise, self.sr)
        self.assertGreater(m.spectral_flatness, 0.5)

    def test_mismatched_lengths_are_truncated_not_errored(self):
        clean = self.noisy[:-100].copy()
        m = calculate_metrics(self.noisy, clean, self.sr)
        self.assertIsNotNone(m.level_change_db)

    def test_empty_arrays_raise_metrics_error(self):
        with self.assertRaises(MetricsError):
            calculate_metrics(np.array([]), np.array([]), self.sr)


if __name__ == "__main__":
    unittest.main()
