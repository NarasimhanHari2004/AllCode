import os
import tempfile
import unittest

from anc_denoiser.config import DenoiserConfig, load_config
from anc_denoiser.exceptions import ConfigError


class TestConfigDefaults(unittest.TestCase):
    def test_defaults_are_valid(self):
        DenoiserConfig().validate()  # should not raise

    def test_invalid_model_name_raises(self):
        with self.assertRaises(ConfigError):
            DenoiserConfig(model_name="not_a_model").validate()

    def test_overlap_must_be_less_than_chunk_len(self):
        with self.assertRaises(ConfigError):
            DenoiserConfig(chunk_len_sec=5.0, overlap_sec=5.0).validate()

    def test_dry_wet_ratio_out_of_range_raises(self):
        with self.assertRaises(ConfigError):
            DenoiserConfig(dry_wet_ratio=1.5).validate()

    def test_negative_max_retries_raises(self):
        with self.assertRaises(ConfigError):
            DenoiserConfig(max_retries=-1).validate()


class TestConfigLoading(unittest.TestCase):
    def test_yaml_overrides_defaults(self):
        with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False) as f:
            f.write("model_name: dns48\nchunk_len_sec: 5.0\n")
            path = f.name
        try:
            cfg = load_config(yaml_path=path)
            self.assertEqual(cfg.model_name, "dns48")
            self.assertEqual(cfg.chunk_len_sec, 5.0)
        finally:
            os.unlink(path)

    def test_unknown_yaml_key_raises(self):
        with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False) as f:
            f.write("not_a_real_field: 123\n")
            path = f.name
        try:
            with self.assertRaises(ConfigError):
                load_config(yaml_path=path)
        finally:
            os.unlink(path)

    def test_missing_yaml_file_raises(self):
        with self.assertRaises(ConfigError):
            load_config(yaml_path="/nonexistent/path/config.yaml")

    def test_env_var_overrides_default(self):
        os.environ["ANC_MODEL_NAME"] = "master64"
        try:
            cfg = load_config()
            self.assertEqual(cfg.model_name, "master64")
        finally:
            del os.environ["ANC_MODEL_NAME"]

    def test_cli_overrides_win_over_env_and_yaml(self):
        os.environ["ANC_MODEL_NAME"] = "master64"
        try:
            cfg = load_config(cli_overrides={"model_name": "dns48"})
            self.assertEqual(cfg.model_name, "dns48")
        finally:
            del os.environ["ANC_MODEL_NAME"]

    def test_none_cli_overrides_are_ignored(self):
        cfg = load_config(cli_overrides={"model_name": None})
        self.assertEqual(cfg.model_name, "dns64")


if __name__ == "__main__":
    unittest.main()
