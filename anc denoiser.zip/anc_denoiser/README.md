# anc-denoiser

Production speech-denoising pipeline for ANC evaluation. Four interchangeable
architectures share one config/logging/metrics/audio-IO core, instead of the
original four independent, drifting copy-pasted scripts.

## Install

```bash
git clone <this repo>
cd anc_denoiser
pip install -e .
# optional extras:
pip install -e ".[perceptual]"   # pesq + pystoi, for PESQ/STOI scoring
pip install -e ".[frcrn]"        # clearvoice, for Architecture 4 only
pip install -e ".[dev]"          # pytest, ruff, mypy

# GPU: install the matching CUDA wheel index for your driver, e.g.
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu130
```

## CLI — one command per architecture

```bash
# Architecture 1: chunked (fastest, simplest)
anc-denoise chunked -i test_input.wav -o cleaned.wav

# Architecture 2: overlap-add, equal-power crossfade (smoothest boundaries)
anc-denoise overlap_add -i test_input.wav -o cleaned.wav

# Architecture 3: overlap-add + dry/wet blend (configurable ratio)
anc-denoise dry_wet_blend -i test_input.wav -o cleaned.wav --dry-wet-ratio 0.97

# Architecture 4: ClearVoice FRCRN (best measured PESQ/STOI; no native batch support)
anc-denoise frcrn -i test_input.wav -o cleaned.wav
```

Numeric aliases also work: `anc-denoise 1 -i ...` == `anc-denoise chunked -i ...`.

With a real clean reference file, add PESQ/STOI scoring:
```bash
anc-denoise overlap_add -i noisy.wav -o cleaned.wav -r clean_reference.wav
```

Batch mode (folder in, folder out; skipped files are logged and don't abort the run):
```bash
anc-denoise overlap_add -i noisy_dir/ -o out_dir/ --batch --json-summary results.json
```

Full flag list: `anc-denoise --help`.

## Configuration

Precedence (highest wins): **CLI flags > environment variables > YAML config
file > built-in defaults**.

```bash
anc-denoise overlap_add --config configs/default.yaml -i in.wav -o out.wav
```

```bash
cp .env.example .env   # edit, then:
export $(cat .env | xargs)
anc-denoise overlap_add -i in.wav -o out.wav
```

See `src/anc_denoiser/config.py` for the full `DenoiserConfig` field list and
validation rules, and `configs/default.yaml` for a documented example.

## Tests

```bash
pytest tests/ -v
# or, without installing the package:
PYTHONPATH=src python3 -m unittest discover -s tests -v
```

The pure-logic modules (`config`, `metrics`, `audio_io`, `architectures.overlap_add`'s
windowing function) are import-safe and fully testable without torch/librosa
installed — heavy dependencies are imported lazily inside the functions that
actually need them.

## What changed from the original four scripts (production fixes)

**Correctness bugs fixed:**
- `level_change_db` sign was inverted (quieter output read as positive dB) — carried over from the original scripts, kept fixed here.
- **Edge-fade bug** (new finding, confirmed with a numeric identity-reconstruction test in `tests/test_overlap_add_window.py`): the overlap-add crossfade window was applied unconditionally to every chunk, including the first and last. That silently attenuated the first/last `overlap_sec` of *every output file* toward silence, since there's no neighboring chunk on that edge to blend with. Fixed by only fading in on non-first chunks and fading out on non-last chunks.
- ClearVoice can return a dict or list depending on configuration; `.ndim` was called on it directly. Normalized before use.
- `os.path.splitext()` + string concatenation crashed with `TypeError` in the batch path of the original Architecture-3 script (splitext returns a tuple). Fixed.
- `os.startfile()` is Windows-only; cross-platform open added (`open` on macOS, `xdg-open` on Linux), and made a no-op unless `interactive_plots` is explicitly enabled — a server/CI run has no display to show a window on.

**Output quality:**
- Output loudness now RMS-matched to the input before saving (peak-limited). PESQ/STOI are both sensitive to reference/degraded level mismatches; your original measurements showed -6.5 to -7.8 dB of level drop, which likely cost real PESQ/STOI score independent of actual denoising quality.
- Overlap-add crossfade changed from linear to equal-power (raised cosine) — avoids the perceived loudness dip inherent to linear amplitude crossfades between uncorrelated segments.
- Architecture 3's dry/wet ratio is now configurable (`dry_wet_ratio`, default 0.97 wet) instead of hardcoded 0.90 — your measured results showed the 90/10 blend cost ~20 dB of SNR improvement and the lowest PESQ/STOI of all four architectures.
- Default model bumped to `dns64` (was `dns48`) for the Demucs-family architectures; override with `--model dns48` for a speed/quality tradeoff.

**Robustness:**
- Real `logging` module (levels, timestamps, optional file output) instead of bare `print()`.
- Typed exception hierarchy (`exceptions.py`) so the CLI can distinguish config errors, bad input files, model-load failures, and per-file inference failures.
- Model loading retries with backoff (`max_retries`/`retry_backoff_sec`) for transient weight-download failures.
- Batch runs no longer abort on one bad file — failures are logged and the run continues, with a final `X/N succeeded` summary and optional `--json-summary` output.
- Input validation (missing file, empty file, wrong extension, NaN/Inf samples, empty decoded audio) raises clear, typed errors instead of an opaque traceback partway through inference.

**Code quality / deployment:**
- The ~40-line metrics function, previously copy-pasted identically into all four scripts, now lives in one place (`metrics.py`).
- Full type hints, docstrings, and `pyproject.toml` packaging with a console-script entry point (`anc-denoise`).
- No hardcoded Windows paths; config-file + env-var driven instead of editing script defaults by hand.
- 27 unit tests covering metrics correctness (including a regression test locking in the level_change_db sign and the edge-fade fix), loudness matching, and config precedence/validation.

## Known limitations / next steps

- PESQ/STOI absolute scores in your last run (1.08–1.30 out of ~4.5) still indicate real headroom beyond what these fixes alone will close — worth checking input SNR/duration and considering a stronger base model.
- Architecture 4 (FRCRN) doesn't support the input's own batch loop the way the Demucs-family architectures do at the model level; the CLI loops per-file around it instead, which is correct but slower than a native batched call would be.
